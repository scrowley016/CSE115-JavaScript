//Write a function named "copyInput" that that doesn't take any parameters and doesn't return a value. This function should find an HTML element with an id of "user_input", which will be a text box, and set this value as the HTML inside an element with an id of "copied_input"

function copyInput(){
    var copy= document.getElementById("user_input").value;
    document.getElementById("copied_input").innerHTML = copy;
    
}


//Write a function named "insertWord" that that doesn't take any parameters and doesn't return a value. This function should find an HTML element with an id of "content" and replace its innerHTML with the string "dissolve"

function insertWord(){
    var insert= document.getElementById("content").value;
    document.getElementById("content").innerHTML = "dissolve";
    
}

//Write a function named "additionCalculator" that that doesn't take any parameters and doesn't return a value. This function will control the logic for a web-based calculator that adds two numbers (You can make more complex calculators this way, but we'll only add numbers for now so we can focus on the concept). There will be two text boxes on the web page with ids of "input_one" and "input_two" and an empty div with an id of "sum". Read the values of the two text boxes and write the addition of these two values inside the div. Note that every value you read from the page will be a string and you'll need to convert them to Numbers to perform the addition
function additionCalculator(){
    var x= document.getElementById("input_one").value;
    var y= document.getElementById("input_two").value;
    var add = Number(x)+Number(y);
    var sum= document.getElementById("sum").innerHTML = add;
}

//Write a function named "plotLine" that takes an array of points where each element is an array in the format [x, y] and both x and y are floating points Numbers. The function will create a line chart in a div with id of "plot" using the Plotly library. You may assume that your code runs on a page where Plotly is downloaded

//Documentation: https://plot.ly/javascript/

function plotLine(param){
    var data = [{
        x: [],
        y: [],
        divId:'plot'
        
    }];
    for(i=0;i<param.length;i++){
        data[0].x.push(param[i][0]);
        data[0].y.push(param[i][1]);
        
    }
    Plotly.newPlot('plot', data);
  }

//Write a function named "plotPie" that takes an array where each element is an array in the format [x, Label]. Each x is a floating point Number representing a value and each Label is a String representing the label for that value. The function will create a pie chart with this data in a div with an id of "plot" using the Plotly library. You may assume that your code runs on a page where Plotly is downloaded

//Documentation: https://plot.ly/javascript/

function plotPie(params) {
var data = [{
values: [],
labels: [],
type: 'pie'
}];
  
for(i=0;i<params.length;i++)
{
data[0].values.push(params[i][0]);
data[0].labels.push(params[i][1]);
}

Plotly.newPlot('plot', data);
  
}