//Write a function named "read_json" that takes a JSON formatted string as a parameter and return the data represented by the input in the appropriate types for this language. For example, if the input string represents a JSON object you should return a key-value store containing the same data

function read_json(string){
    var object= JSON.parse(string);
    return object;
}

//Write a function named "to_json" that takes any valid type as a parameter and returns the input as a JSON formatted string. For example, if the input is a key-value store this function should return a JSON string representing an object containing the same data

function to_json (input){
    var object= JSON.stringify(input);
    return object;
}

//Write a function named "get_y" that takes a JSON formatted string as a parameter in the format of an object with keys "x" and "y" each mapping to an array of integers. This is the same format used to plot points on a line graph in Plotly in that each (x[i], y[i]) represents a single point. Return the y-value at x == -9

function get_y(string){
    var object= JSON.parse(string);
    var x= string['x'];
    var y= string['y'];
    for (var items of x){
        if (x[items]=== -9){
            return y[items] ;
        }
    }
}

//Write a function named "get_value" that takes a JSON formatted string as a parameter in the format "{"attack": <float>, "decay": <float>, "sustain": <float>, "release": <float>}" and returns the value at the key "attack"

function get_value(strings) {
    var data = JSON.parse(strings);
    return data.release;
}

//Write a function named "get_y" that takes a JSON formatted string as a parameter in the format of an object with keys "x" and "y" each mapping to an array of integers. This is the same format used to plot points on a line graph in Plotly in that each (x[i], y[i]) represents a single point. Return the y-value at x == 11

function get_y(strings) {
    data = JSON.parse(strings);
    var x = data["x"];
    var y = data["y"];
    for (var i = 0; i < x.length; i++) {
        if (x[i] === 11) {
            return y[i];
        }
    }
}

//Write a function named "json_average" that takes a JSON formatted string as a parameter in the format of an array of objects where each object has keys "mass", "density", "temperature", and "velocity" and each key maps to a floating point number. This function should return the average "mass" of all the objects in the array as a JSON string in the format {"mass": <Number>}

function json_average(string) {
    data = JSON.parse(string);
    var total = 0;
    for (var i = 0; i < data.length; i++)
        total += data[i]["mass"];
    return JSON.stringify({"mass": total/data.length});
}
