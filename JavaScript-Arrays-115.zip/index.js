//Write a function named "create_data_structure" that takes no parameters and returns a new list with the values 7, -8, -5, 19, -3, and 4 in this order

function create_data_structure(){
    var new_list= [7,-8,-5,19,-3,4];
    return new_list;
}

//Write a function named "get_value" that takes a list as a parameter and returns the value stored at index 6 from the input

function get_value(lists){
    return lists[6];
}

//Write a function named "print_list" that takes a list of strings as a parameter and prints each element of the list on a separate line. That is, it prints all elements of the list separated by new line characters

function print_list(new_list){
    var i;
    for (i=0;i<new_list.length;i++) {
        console.log(new_list[i]);
    }
}

//Write a function named "list_concat" that takes a list of strings as a parameter and returns the concatenation of all the values in the list as a single string with each value separated by a space. For example, if the input is ["limit", "break", "ready"] the output should be "limit break ready"

function list_concat(words){
        return words.join(" ");
}

//Write a function named "indexed_list" that doesn't take any parameters and returns a new list containing the integers from 0 to 40 in order (include both 0 and 40 in your list)

function indexed_list(){
    new_array=[];
    var i;
    for(i=0;i<41;i++){
        new_array.push(i);
    }
    return new_array;
}

//Write a function named "list_sum" that takes a list of floating point numbers as a parameter and returns the sum of all the numbers in the list

function list_sum(num){
    var start=0.0;
    for(var i of num){
        start=start+i;
    }
    return start;
}

//Write a function named "count_values" that takes a list of integers as a parameter and returns the number of values in the list that are strictly greater than 525
function count_values(num){
    var i;
    var new_array=[];
    for (i of num){
        if(i>525){
            new_array.push(i);
        }
    }
    return new_array.length;
}

//Write a function named "add_value" that takes a list as a parameter and adds the value 46 to the end of the input list (after the last element). The function does not have to return a value

function add_value(my_list){
    return my_list.push(46);
}

//Write a function named "count_in_range" that takes a list of numbers as a parameter and returns the number of values in the input that are between 22.01 and 47.28 not including these end points

function count_in_range(new_list){
    var i;
    var new_array =[];
    for (i in new_list){
        if (i>22.01 && i<47.28){
            new_array.push(i);
        }
    }
    return new_array.length;
}