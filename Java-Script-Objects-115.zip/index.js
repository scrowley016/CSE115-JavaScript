//Write a function named "create_kv" that doesn't take any parameters and returns a new key-value store containing the key-values pairs of "nod": -11 and "electronic": 9

function create_kv(){
    var object={
        "nod": -11,
        "electronic": 9
    }
    return object;
}

//Write a function named "create_kv" that doesn't take any parameters and returns a new key-value store containing the key-values pairs of "clay": 7, "labor": -11, and "contractor": -20

function create_kv(){
    object={
        "clay":7,
        "labor":-11,
        "contractor": -20
    };
    return object;
}

// You are writing a function that will be used in a RPG that will take a character's stat sheet and return a the characters "Dexterity" stat.

//Write a function named "get_stat" that takes a key-value store as a parameter with strings as keys and integers as values. The keys include "Strength", "Constitution", "Defense", "Dexterity", "Intelligence", "Charisma", "Willpower", and "Luck" and each value is an integer between 0 and 255. This function should return the value for the "Dexterity" stat

function get_stat(object){
    return object["Dexterity"];
}

//Write a function named "add_key_value" that takes a key-value store as a parameter with strings as keys and integers as values. The function will add a key-value pair to the input store with a key of "isolate" and a value of 15. There is no need to return any value

function add_key_value(object){
    object["isolate"]=15;
}
//Write a function named "print_values" that takes a key-value store as a parameter with strings as keys and integers as values. The function prints each value of the input on a separate line. That is, it prints all values of the key-value store separated by new line characters

function print_values(object){
    for (var items in object){
        console.log(object[items]);
    }
}


//Write a function named "sum_values" that takes a key-value store as a parameter with strings as keys and floating point numbers as values and returns the sum of all the values from the input
function sum_values(word){
    var count=0;
    for (var items in word){
        count=count+word[items];
    }
    return count;
}

//Write a function named "indexed_kvs" that doesn't take any parameters and returns a new key-value store containing the integers from 0 to 27 as values each stored at a key which is a string containing the digits of the integer. For example the key-value "0":0 will be in your returned key-value store (include both 0 and 27 in your list)

function indexed_kvs(){
    var my_object= {};
    for (i=0;i<=27;i++){
        my_object[i]=i;
    }return my_object;
}

//Write a function named "get_size" that takes a key-value store as a parameter with strings as keys and integers as values and returns the number of key-value pairs in the input

function get_size(kvs){
    count=0;
    for (var items in kvs){
        count=count+1;
    }
    return count;
}

//Write a function named "print_keys" that takes a key-value store as a parameter with strings as keys and integers as values. The function prints each key of the input on a separate line. That is, it prints all keys of the key-value store separated by new line characters

function print_keys(store) {
    for (var key in store) {
        if (store.hasOwnProperty(key)) {
            console.log(key);
        }
    }
}


//Write a function named "find_value" that takes a key-value store as a parameter with strings as keys and integers as values. The function returns a boolean representing true if the value 8 is in the input as a value, false otherwise

function find_value(store) {
    for (var key in store) {
        if (store.hasOwnProperty(key) && store[key] === 8) {
            return true;
        }
    }
    return false;
}

//Write a function named "find_key" that takes a key-value store as a parameter with strings as keys and integers as values. The function returns a boolean representing true if the string "inspire" is in the input as a key, false otherwise

function find_key(store) {
    for (var key in store) {
        if (store.hasOwnProperty(key) && store[key] === "inspire") {
            return true;
        }
    }
    return false;
}
//Write a function named "count_large" that takes a key-value store as a parameter with strings as keys and floating point numbers as values and returns the number of values that are greater than 44.82

function count_large(kvs){
    var count=0;
    for(var items in kvs){
        if(kvs.hasOwnProperty(items) && kvs[items]> 44.82){
            count=count+1;
        }
    }return count;
}

