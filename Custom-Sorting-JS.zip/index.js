//Write a function named "sort_by_length" that takes a list/array of strings as a parameter and sorts the strings by their length

function sort_by_length(param) {
    param.sort(function (x, y) {
        if (x.length < y.length) return -1;
        if (x.length > y.length) return 1;
        return 0;
    });
}

//Write a function named "sort_kvs" that takes a list/array of key-value stores as a parameter where each key-value store has keys "power", "purity", "strike", "ability", and "spin" all mapping to integer values. Sort the input based on the values at the key "strike"

function sort_kvs(param) {
    param.sort(function (x,y) {
        if (x["strike"] < y["strike"]) return -1;
        if (x["strike"] > y["strike"]) return 1;
        return 0;
    });
    return param;
}

//Write a function named "sort_by_index" that takes a list/array of lists/arrays as a parameter where each of the values of input is a list containing 6 integer values. Sort the input based on the values of the first value in each list

function sort_by_index(param) {
    param.sort(function (x, y) {
        if (x[0] < y[0]) return -1;
        if (x[0] > y[0]) return 1;
        return 0;
    });
    return param;
}

//Write a function named "sort_by_product" that takes a list/array of lists/arrays as a parameter where each of the values of input is a list containing 6 floating point numbers. Sort the input based on multiplication of the sixth and second values in each list

function sort_by_product(param) {
    param.sort(function (x, y) {
        if (x[5]*x[1] < y[5]*y[1]) return -1;
        if (x[5]*x[1] > y[5]*y[1]) return 1;
        return 0;
    });
    return param;
}


//Write a function named "sort_by_average_rating" that takes a list/array of key-value stores as a parameter where each key-value store has keys "ratings", "budget", and "box_office" where budget and box_office are integers and ratings is a list of integers. Sort the input based on the average of the values in "ratings"

function sort_by_average_rating(stores) {
    stores.sort(function (n1, n2) {
        var avg1 = 0, avg2 = 0;
        n1 = n1["ratings"];
        n2 = n2["ratings"];
        for (var i = 0; i < n1.length; i++) {
            avg1 += n1[i];
        }
        for (var i = 0; i < n2.length; i++) {
            avg2 += n2[i];
        }
        avg1 /= n1.length;
        avg2 /= n2.length;
        console.log(avg1 + "\t" + avg2);
        if (avg1 < avg2) return -1;
        if (avg1 > avg2) return 1;
        return 0;
    });
    return stores;
}


